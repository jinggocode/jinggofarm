<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="https://v40.pingendo.com/assets/bootstrap/bootstrap-4.0.0-beta.1.css" type="text/css"> </head>
  <style> 
    body { 
          background-image: url(https://i.imgur.com/OJIcIns.jpg) ;
          background-position: center center;
          background-repeat:  no-repeat;
          background-attachment: fixed;
          background-size:  cover;
          background-color: #999;
      
    } 
  </style>
<body>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-3"> </div>
        <div class="col-md-6">
          <div class="card p-2">
            <div class="card-body">
              <h1 class="mb-1 text-secondary">Login form</h1>
              <hr class="secondary border-secondary mx-0" style="border-width: 5px; width: 8%; margin-top: 10px; margin-bottom: 30px">
                
                <?php if ($message): ?> 
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <strong>Peringatan!</strong><br> <?php echo $message; ?>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <?php endif ?>

              <form method="post" action="{{site_url('auth/login')}}">
                <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" />

                <div class="form-group"> 
                    <label class="text-dark" for="identity">Email address</label>
                    <?php echo form_input($identity);?>   
                </div>
                <div class="form-group"> 
                    <label class="text-dark"for="password">Password</label>
                    <?php echo form_input($password);?> 
                </div>

                <button type="submit" class="btn btn-secondary"><i class="fa fa-sign"></i>Login</button>
                
              </form>
              <p class="mt-3">Belum punya akun? </p>
              <a href="" class="btn btn-primary btn-block">Daftar</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

</body>

</html>