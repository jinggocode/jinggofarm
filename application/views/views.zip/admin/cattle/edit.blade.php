@layout('_layout/index')

@section('title')Edit Pasar@endsection 

@section('content')
<div id="page-content">
    <!-- Blank Header -->
    <div class="content-header">
        <div class="row">
            <div class="col-sm-6">
                <div class="header-section">
                    <h1>Edit Pasar</h1>
                </div>
            </div> 
        </div>  

    </div>
    <!-- END Blank Header -->
 
<br>
    <div class="row">
        <div class="col-sm-6 col-lg-12">
            <!-- Form Alert -->
            @if (!empty(validation_errors()))
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><strong>Peringatan</strong></h4>
                <p>{{validation_errors()}}</p>
            </div>
            @endif
            <!-- END Form Alert -->
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <!-- Horizontal Form Block -->
            <div class="block"> 

                <form action="{{site_url($page.'/update')}}" method="post" class="form-horizontal form-bordered" enctype="multipart/form-data">
                {{$csrf}} 
                {{form_hidden('id', $data->id)}}
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="kode_jenis">Jenis Pasar</label>
                        <div class="col-md-3">
                            <select name="kode_jenis" id="kode_jenis" required="required" class="form-control">
                                <option value=""></option>
                                @foreach ($jenis as $value) 
                                <option {{($data->kode_jenis == $value->kode_jenis)?'selected':''}} value="{{$value->kode_jenis}}">{{$value->jenis_pasar}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="kelas">Kelas</label>
                        <div class="col-md-2">
                            <select name="kelas" id="kelas" required="required" class="form-control">
                                <option value=""></option> 
                                <option {{($data->kelas == 'I')?'selected':''}} value="I">I</option> 
                                <option {{($data->kelas == 'II')?'selected':''}} value="II">II</option> 
                                <option {{($data->kelas == 'III')?'selected':''}} value="III">III</option> 
                            </select>
                        </div>
                    </div> 
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="kode_pasar">Kode Pasar</label>
                        <div class="col-md-3">
                            <input value="{{$data->kode_pasar}}" type="text" id="kode_pasar" name="kode_pasar" class="form-control"> 
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="kode_sk">Kode SK</label>
                        <div class="col-md-3">
                            <input value="{{$data->kode_sk}}" type="text" id="kode_sk" name="kode_sk" class="form-control"> 
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="nama_pasar">Nama Pasar</label>
                        <div class="col-md-3">
                            <input value="{{$data->nama_pasar}}" type="text" id="nama_pasar" name="nama_pasar" class="form-control"> 
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="koordinator">Nama Koordinator</label>
                        <div class="col-md-5">
                            <input value="{{$data->koordinator}}" type="text" id="koordinator" name="koordinator" class="form-control"> 
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="NIP">NIP</label>
                        <div class="col-md-3">
                            <input value="{{$data->NIP}}" type="text" id="NIP" name="NIP" class="form-control"> 
                        </div>
                    </div> 
                    <div class="form-group">
                        <label class="col-md-3 control-label" for="description">Foto Denah</label>
                        <div class="col-md-5">
                            <input type="file" name="denah" class="form-control">   <br> 
                            <?php $img = isset($data->denah) ? $data->denah : 'default.png';?> 
                            <img width="300" height="1000" src="{{base_url('uploads/img/denah/'.$img)}}" class="image-preview img-responsive" alt=""> 
                        </div>
                    </div>
                    <div class="form-group form-actions">
                        <div class="col-md-9 col-md-offset-3">
                            <button type="submit" class="btn btn-effect-ripple btn-primary" style="overflow: hidden; position: relative;"><i class="fa fa-send"></i> Ubah</button>
                            <button type="reset" class="btn btn-effect-ripple btn-danger" style="overflow: hidden; position: relative;"><i class="fa fa-refresh"></i> Reset</button>
                            <a href="{{site_url($page)}}" class="btn btn-effect-ripple btn-warning" style="overflow: hidden; position: relative;"><i class="fa fa-chevron-left"></i> Kembali</a>
                        </div>
                    </div>
                </form>
            </div>
            <!-- END Horizontal Form Block --> 
        </div> 
    </div>
</div>
@endsection 

@section('script')  
     <!-- ckeditor.js, load it only in the page you would like to use CKEditor (it's a heavy plugin to include it with the others!) -->
    <script src="{{base_url('assets/dashboard/')}}js/plugins/ckeditor/ckeditor.js"></script>

    <script src="{{base_url('assets/dashboard/')}}js/pages/formsComponents.js"></script> 
    <script type="text/javascript" src="{{base_url('assets/dashboard/js/plugins/datetime/jquery.datetimepicker.min.js')}}"></script>
    <script type="text/javascript" src="{{base_url('assets/dashboard/js/plugins/datetime/jquery.datetimepicker.full.min.js')}}"></script>
    <script type="text/javascript">
        $(function(){
            $("[type='date']").prop('type', 'text').datetimepicker();
        });
    </script>
    <script>$(function(){ FormsComponents.init(); });</script> 
    <script type="text/javascript">
    var articles = (function(){ 
        // bind events 
        $("[type='file']").on('change', eventPreviewGambar); 

        init(); 

        // Events  
        function eventPreviewGambar(event){
            readURL(event.target);
        } 

        function readURL(input){
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('.image-preview').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

    })();
</script>
@endsection