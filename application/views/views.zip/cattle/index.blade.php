@layout('_layout/index')

@section('title')Nama Ternak@endsection

@section('style')
<style>

.card:hover{ 
   box-shadow: 4px 8px 20px grey;
  -webkit-transition:  box-shadow .2s ease-in;
}

</style>
@endsection
  
@section('content') 
<div class="text-center opaque-overlay" style="background-image: url(&quot;https://i.imgur.com/OJIcIns.jpg&quot;);">
    <div class="container py-5">
      <div class="row">
        <div class="col-md-12 text-white">
          <h1 class="display-4 mb-4 text-left"><b>Daftar Ternak Investasi</b></h1>
        </div>
      </div>
    </div>
  </div> 
  <div class="text-dark py-3">
    <div class="container"> 
      <div class="row">
        <div class="col-md-4 my-3">
          <div class="card">
            <img class="img-fluid" src="https://3.bp.blogspot.com/-obVSA_LEvu8/V45FMK1JRbI/AAAAAAAAD6E/8Dq9-SaCyewp0Y9AueMUGuWCfxW-dfRcACLcB/s400/cara%2Bbudidaya%2Bsapi%2Bperah.JPG" alt="Card image">
            <div class="card-body bg-primary">
              <h4 class="card-subtitle text-light">Sapi Friesian Holstein (FH)</h4>
              <p class="card-text p-y-1 w-100 py-2 text-light">Profit 10-20%
                <br>Periode 4 Tahun</p>
              <a href="{{site_url('cattle/view')}}" class="card-link btn btn-secondary">Lihat Detail</a>
            </div>
          </div>
        </div>
        <div class="col-md-4 my-3">
          <div class="card">
            <img class="img-fluid" src="https://3.bp.blogspot.com/-obVSA_LEvu8/V45FMK1JRbI/AAAAAAAAD6E/8Dq9-SaCyewp0Y9AueMUGuWCfxW-dfRcACLcB/s400/cara%2Bbudidaya%2Bsapi%2Bperah.JPG" alt="Card image">
            <div class="card-body bg-primary">
              <h4 class="card-subtitle text-light">Sapi Friesian Holstein (FH)</h4>
              <p class="card-text p-y-1 w-100 py-2 text-light">Profit 10-20%
                <br>Periode 4 Tahun</p>
              <a href="{{site_url('cattle/view')}}" class="card-link btn btn-secondary">Lihat Detail</a>
            </div>
          </div>
        </div>
        <div class="col-md-4 my-3">
          <div class="card">
            <img class="img-fluid" src="https://3.bp.blogspot.com/-obVSA_LEvu8/V45FMK1JRbI/AAAAAAAAD6E/8Dq9-SaCyewp0Y9AueMUGuWCfxW-dfRcACLcB/s400/cara%2Bbudidaya%2Bsapi%2Bperah.JPG" alt="Card image">
            <div class="card-body bg-primary">
              <h4 class="card-subtitle text-light">Sapi Friesian Holstein (FH)</h4>
              <p class="card-text p-y-1 w-100 py-2 text-light">Profit 10-20%
                <br>Periode 4 Tahun</p>
              <a href="{{site_url('cattle/view')}}" class="card-link btn btn-secondary">Lihat Detail</a>
            </div>
          </div>
        </div>
      </div>
    </div> 
  </div> 
@endsection