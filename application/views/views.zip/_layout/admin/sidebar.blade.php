<div id="sidebar-alt" tabindex="-1" aria-hidden="true">
    <!-- Toggle Alternative Sidebar Button (visible only in static layout) -->
    <a href="javascript:void(0)" id="sidebar-alt-close" onclick="App.sidebar('toggle-sidebar-alt');"><i class="fa fa-times"></i></a>

    <!-- Wrapper for scrolling functionality -->
    <div id="sidebar-scroll-alt">
        <!-- Sidebar Content -->
        <div class="sidebar-content"> 

            <!-- Settings -->
            <div class="sidebar-section">
                <h2 class="text-light">Settings</h2>
                <form action="index.html" method="post" class="form-horizontal form-control-borderless" onsubmit="return false;">
                    <div class="form-group">
                        <label class="col-xs-7 control-label-fixed">Notifikasi</label>
                        <div class="col-xs-5">
                            <label class="switch switch-success"><input type="checkbox" checked><span></span></label>
                        </div>
                    </div> 
                    <div class="form-group remove-margin">
                        <button type="submit" class="btn btn-effect-ripple btn-primary" onclick="App.sidebar('close-sidebar-alt');">Save</button>
                    </div>
                </form>
            </div>
            <!-- END Settings -->
        </div>
        <!-- END Sidebar Content -->
    </div>
    <!-- END Wrapper for scrolling functionality -->
</div>

<div id="sidebar">
    <!-- Sidebar Brand -->
    <div id="sidebar-brand" class="themed-background">
        <a href="index.html" class="sidebar-title">
            <i class="fa fa-cube"></i> <span class="sidebar-nav-mini-hide">E-Mang <strong>PAS</strong></span>
        </a>
    </div>
    <!-- END Sidebar Brand -->

    <!-- Wrapper for scrolling functionality -->
    <div id="sidebar-scroll">
        <!-- Sidebar Content -->
        <div class="sidebar-content">

            <?php $page = $this->uri->segment(1); ?>
            <?php $sub_page = $this->uri->segment(1); ?>

            <!-- Sidebar Navigation -->
            <ul class="sidebar-nav">
                <li class="{{($page == "home")?'active' : ''}}">
                    <a href="{{site_url('admin/dashboard')}}"><i class="gi gi-dashboard sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Beranda</span></a>
                </li>  
                <li class="sidebar-separator">
                    <i class="fa fa-ellipsis-h"></i>
                </li> 
                <li class="{{($page == "ternak" || $page == "peternak")?'active' : ''}}">
                    <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-file-text-o sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Kelola Data</span></a>
                    <ul>
                        <li class="{{($page == "pasar")?'active' : ''}}">
                            <a href="{{site_url('pasar')}}"><i class="fa fa-building sidebar-nav-icon"></i> Data Ternak</a>
                        </li>   
                        <li class="{{($page == "target")?'active' : ''}}">
                            <a href="{{site_url('target')}}"><i class="fa fa-share-alt sidebar-nav-icon"></i> Data Peternak</a>
                        </li>     
                    </ul>
                </li>   
                <li class="{{($page == "users")?'active' : ''}}">
                    <a href="{{site_url('dashboard/users')}}"><i class="gi gi-user_add sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Kelola Transaksi</span></a>
                </li>   
                <li class="{{($page == "events" || $page == "categories_event")?'active' : ''}}">
                    <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-calendar sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Pelaporan Ternak</span></a>
                    <ul>
                        <li class="{{($page == "events" && $sub_page == "")?'active' : ''}}">
                            <a href="{{site_url('dashboard/events')}}"><i class="fa fa-pencil sidebar-nav-icon"></i> Perkembangan Ternak</a>
                        </li>   
                        <li class="{{($page == "categories_event")?'active' : ''}}">
                            <a href="{{site_url('dashboard/categories_event')}}"><i class="fa fa-list sidebar-nav-icon"></i> Penggunaan Dana</a>
                        </li>    
                        <li class="{{($page == "categories_event")?'active' : ''}}">
                            <a href="{{site_url('dashboard/categories_event')}}"><i class="fa fa-print sidebar-nav-icon"></i> Penjualan Hasil Ternak</a>
                        </li>    
                    </ul>
                </li>  
                <li class="{{($page == "events" || $page == "categories_event")?'active' : ''}}">
                    <a href="#" class="sidebar-nav-menu"><i class="fa fa-chevron-left sidebar-nav-indicator sidebar-nav-mini-hide"></i><i class="fa fa-calendar sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Kelola Keuangan</span></a>
                    <ul>
                        <li class="{{($page == "events" && $sub_page == "")?'active' : ''}}">
                            <a href="{{site_url('dashboard/events')}}">Konfirmasi Penarikan Saldo</a>
                        </li>   
                        <li class="{{($page == "categories_event")?'active' : ''}}">
                            <a href="{{site_url('dashboard/categories_event')}}">Saldo Kelompok Ternak</a>
                        </li>     
                    </ul>
                </li>  
                <li class="{{($page == "users")?'active' : ''}}">
                    <a href="{{site_url('dashboard/users')}}"><i class="gi gi-user_add sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Keuangan</span></a>
                </li>  
                <li class="sidebar-separator">
                    <i class="fa fa-ellipsis-h"></i>
                </li>
                <li class="{{($page == "users")?'active' : ''}}">
                    <a href="{{site_url('dashboard/users')}}"><i class="gi gi-user sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Pengguna Aplikasi</span></a>
                </li>  
                <li class="{{($page == "users")?'active' : ''}}">
                    <a href="{{site_url('dashboard/users')}}"><i class="gi gi-user sidebar-nav-icon"></i><span class="sidebar-nav-mini-hide">Admin Kelompok Ternak</span></a>
                </li>  
            </ul>
            <!-- END Sidebar Navigation -->
 
        </div>
        <!-- END Sidebar Content -->
    </div>
    <!-- END Wrapper for scrolling functionality -->

    <!-- Sidebar Extra Info -->
    <div id="sidebar-extra-info" class="sidebar-content sidebar-nav-mini-hide">  
        <div class="text-center">
            <small>Crafted with <i class="fa fa-heart text-danger"></i> by <a class="text-primary" href="http://vc.labkode.org" target="_blank">Vensil Creative</a></small><br>
            <small>2017 &copy; <a href="http://goo.gl/RcsdAh" target="_blank">v.0.1</a></small>
        </div>
    </div>
    <!-- END Sidebar Extra Info -->
</div>