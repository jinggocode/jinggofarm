<nav class="navbar navbar-expand-md bg-secondary navbar-dark">
  <div class="container">
    <a class="navbar-brand" href="#"><b>  <img src="https://i.imgur.com/nvFaZQC.png" width="160"></b></a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
      aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto"> </ul>
      <ul class="navbar-nav right">
        <li class="nav-item">
          <a class="nav-link text-light" href="#"><i class="fa d-inline fa-lg fa-home"></i> Beranda</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="#"><i class="fa d-inline fa-lg fa-list"></i> Daftar Ternak</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="#"><i class="fa d-inline fa-lg fa-question-circle"></i> FAQ</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="#"><i class="fa d-inline fa-lg fa-envelope-o"></i> Bantuan</a>
        </li>
      </ul>
      <div class="btn-group px-3">
        <?php 
        $user = $this->ion_auth->user()->row();
        ?>        
        <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown"><i class="fa d-inline fa-lg fa-user-circle-o"></i>&nbsp; {{$user->first_name.' '.$user->last_name}} </button>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="{{site_url('investor')}}">Profil</a> 
          <a class="dropdown-item" href="{{site_url('auth/logout')}}">Logout</a> 
        </div>
      </div>
    </div>
  </div>
</nav>